/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ingesoft;

/**
 *
 * @author Lenovo
 */
    class Node {

        public int data;
        public Node next;
        public Node previous;

        public Node(int nodeData) {
            this.data = nodeData;
            this.next = null;
            this.previous = null;
        }

        static int getKey(Node node) {

            int a = node.data;
            return a;
        }

        static char[] getKeychar(Node node) {

            int a = node.data;
            String s = String.valueOf(a);
            char[] key = s.toCharArray();
            return key;
        }

        public void setNext(Node nod) {
            nod.next = nod;
        }

        public void setPrevious(Node nod) {
            nod.previous = nod;
        }

    }

    class Stack {

        public Node head;
       

        public Stack() {
            this.head = null;
        }

        public int top() {
            int a = Node.getKey(head);
            return a;
        }

        public void push(int data) {
            Node node = new Node(data);
            if (head == null) {
                head = node;
            } else {
                node.next = head;
                head.previous = node;
                head = node;

            }
          

        }

        public int pop() {
            if (head == null) {
                throw new RuntimeException("La lista está vacia");
            } else {
                int key = Node.getKey(head);
                head = head.next;
               
                return key;
            }
        }

        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            Node current = head;
            while (current != null) {
                sb.append(Node.getKeychar(current));
                current = current.next;
                if (current != null) {
                    sb.append("->");
                }
            }
           

            return sb.toString();
        }

        public boolean Empty() {
            boolean b;
            if (head == null) {
                b = true;
            } else {
                b = false;
            }
            return b;
        }

    }

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ingesoft;

import java.util.Arrays;

import java.util.Scanner;


/**
 *
 * @author Lenovo
 */
public class dijkstra {
    
    
    static int [][] matriz_ad(int n){
        Scanner scan = new Scanner(System.in);
        int[][] matriz = new int [n][n];
        
        while (scan.hasNextInt()){
        int in=scan.nextInt();
        int out=scan.nextInt();
        int peso= scan.nextInt();
        matriz[in][out]= peso;
        matriz [out][in]= peso;
        }
        
        return matriz;
        
        
    }
    
  public static void print2D(int mat[][]) 
    { 
        // Loop through all rows 
        for (int[] row : mat) 
  
            // converting each row as string 
            // and then printing in a separate line 
            System.out.println(Arrays.toString(row)); 
    } 
  public static void print1D(Graph[] a){
      for (int i=0;i< a.length;i++){
          System.out.print(a[i].getCosto() + ","+ a[i].getAnterior()+" ");
      }
      System.out.println();
  }
  
  public static Graph[] nodes (int n){
      Graph[] nodas=new Graph[n];
      for(int i=0; i<n;i++){
          nodas[i]= new Graph(9999,0,false);
      }
      return nodas;
  }

  public static void camino_corto(Graph [] n, int n_i,int n_f){
      int estoy=n_f;
      Stack stack= new Stack();
       stack.push(n_f);
      while (estoy != n_i){
         stack.push(n[estoy].getAnterior()) ;
         estoy= n[estoy].getAnterior();
      }
     
      System.out.print("Camino mas corto: "+stack.toString()+ " Costo: "+ n[n_f].getCosto());
      
  }
    
    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        int n= scan.nextInt();
        int [][] m=matriz_ad(n);
        int origen= scan.nextInt();
        int nodo_final= scan.nextInt();
        //print2D(m);
        Graph[] nodos_v= nodes(n);
        
        
        int flags=1;
        int n_p=origen;
        nodos_v[origen]= new Graph(0,origen,true);
        while (flags < n){
          //nodos_v[origen]= new Node(0,origen,true);
          //System.out.println("Estoy en:"+n_p);
          int menor_num=99999;
          int menor=-1;
          for(int i=0; i<n;i++){
              int costo=m[n_p][i];
              if(m[n_p][i]!=0 && (m[n_p][i]+ nodos_v[n_p].getCosto())<nodos_v[i].getCosto()&& nodos_v[i].isFlag()== false){
                  int costo1=m[n_p][i]+nodos_v[n_p].getCosto();
                  nodos_v[i]= new Graph(costo1,n_p,false);
              }
          }
        // print1D(nodos_v);
          for (int i=0;i<n;i++){
              //System.out.print(menor+" ");
              if (nodos_v[i].getCosto() < menor_num &&nodos_v[i].getCosto()!=0 && nodos_v[i].isFlag()== false){
               menor=i; 
               menor_num= nodos_v[i].getCosto();
               
             }
          }
         int costo= m[n_p][menor];
         // nodos_v[menor].setAnterior(origen);
          nodos_v[menor].setFlag(true);
          //print1D(nodos_v);
          flags++;
          n_p=menor;
          
        }
   
        //System.out.print("Final:");
        //print1D(nodos_v);
        camino_corto(nodos_v, origen, nodo_final);
        
       
                
    }
  
}

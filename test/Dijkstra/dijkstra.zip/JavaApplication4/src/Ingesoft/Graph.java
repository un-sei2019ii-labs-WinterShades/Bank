/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ingesoft;


public class Graph {
    int costo;
    int anterior;
    boolean flag;

    public Graph(int costo, int anterior, boolean flag) {
        this.costo = costo;
        this.anterior = anterior;
        this.flag = flag;
    }

    public int getCosto() {
        return costo;
    }

    public void setCosto(int costo) {
        this.costo = costo;
    }

    public int getAnterior() {
        return anterior;
    }

    public void setAnterior(int anterior) {
        this.anterior = anterior;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }
    
        
    
    
}
